﻿Вся актуальная информация доступна в официальной теме: https://bitcointalk.org/index.php?topic=5023676.0
Discord для обсуждения и вопросов: https://discord.gg/RkywAu5

Список возможных комманд можно проверить запустив из консоли: wildrig --help