#!/bin/bash

while true
do
./wildrig-multi --print-full --split-job 4 --algo mtp-tcr --url stratum+tcp://pool.tecracoin.io:4556 --user TQxTbiSoKS4xCtpkKWBM3LTUpiPLc4gRvz --pass x
sleep 5
done
