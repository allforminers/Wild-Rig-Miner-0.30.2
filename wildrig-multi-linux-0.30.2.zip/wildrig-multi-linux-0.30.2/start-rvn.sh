#!/bin/bash

while true
do
./wildrig-multi --print-full --algo kawpow --url stratum+tcp://pool.woolypooly.com:55555 --worker test --user RJjr1sMM2uVsiBpUN86vgbs3JnkPzwfWFD --pass x
sleep 5
done
