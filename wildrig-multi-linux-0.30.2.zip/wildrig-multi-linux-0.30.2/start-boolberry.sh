#!/bin/bash

while true
do
./wildrig-multi --print-full --algo wildkeccak --url stratum+tcp://bbr.luckypool.io:5577 --user 1C4mbAEKiVj4bNqijN6a7BFDUfGDL81CLUNsM2rkaF54Nqxaxo2jiHQPAY8GRcUrHPRK7rzvUShjo7y4AF7b4hrpSEVNGXb --pass x --scratchpad-safe-update --scratchpad-url http://eu-bbr.luckypool.io/scratchpad.bin --scratchpad-file scratchpad.bin
sleep 5
done
